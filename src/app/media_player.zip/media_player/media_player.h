#ifndef APP_MEDIA_PLAYER_H
#define APP_MEDIA_PLAYER_H

#include "sys/interface.h"

extern APP_OBJ media_app;

#endif