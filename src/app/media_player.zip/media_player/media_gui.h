#ifndef APP_MEDIA_ICO_H
#define APP_MEDIA_ICO_H

#ifdef __cplusplus
extern "C"
{
#endif

#include "lvgl.h"
    extern const lv_img_dsc_t app_movie;

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif