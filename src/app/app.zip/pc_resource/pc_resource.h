#ifndef APP_PC_RESOURCE_H
#define APP_PC_RESOURCE_H

#include "sys/interface.h"

extern APP_OBJ pc_resource_app;

#endif