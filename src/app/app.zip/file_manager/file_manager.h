#ifndef APP_FILE_MANAGER_H
#define APP_FILE_MANAGER_H

#include "../../sys/interface.h"

extern APP_OBJ file_manager_app;

#endif