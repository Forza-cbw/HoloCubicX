#ifndef APP_GAME_2048_H
#define APP_GAME_2048_H

#include "sys/interface.h"

extern APP_OBJ game_2048_app;

#endif