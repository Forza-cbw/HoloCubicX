#ifndef APP_IDEA_H
#define APP_IDEA_H

#include "sys/interface.h"



#ifdef __cplusplus
extern "C"
{
#endif

#include "lvgl.h"
    extern const lv_img_dsc_t app_idea;

#ifdef __cplusplus
} /* extern "C" */
#endif

extern APP_OBJ idea_app;

#endif