#ifndef _UI_ANIMATION_H
#define _UI_ANIMATION_H

void ui_update(int);
void create_ui(void *phy_fb, int screen_width, int screen_height,
               int color_bytes, struct EXTERNAL_GFX_OP *gfx_op);


#endif
