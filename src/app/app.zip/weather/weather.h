#ifndef APP_WEATHER_H
#define APP_WEATHER_H

#include "sys/interface.h"

extern APP_OBJ weather_app;

#endif