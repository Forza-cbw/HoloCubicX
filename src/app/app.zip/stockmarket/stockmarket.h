#ifndef APP_STOCKMARKET_H
#define APP_STOCKMARKET_H


#define STOCK_APP_NAME "Stock"
#include "sys/interface.h"

extern APP_OBJ stockmarket_app;

#endif