#ifndef APP_SETTINGS_H
#define APP_SETTINGS_H

#include "sys/interface.h"

extern APP_OBJ settings_app;

#endif