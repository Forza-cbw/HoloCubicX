#ifndef APP_ANNIVERSARY_H
#define APP_ANNIVERSARY_H

#include "sys/interface.h"

extern APP_OBJ anniversary_app;

#endif