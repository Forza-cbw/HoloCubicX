#ifndef APP_SCREEN_SHARE_H
#define APP_SCREEN_SHARE_H

#include "sys/interface.h"

extern APP_OBJ screen_share_app;

#endif