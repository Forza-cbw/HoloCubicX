#ifndef APP_EXAMPLE_H
#define APP_EXAMPLE_H

#include "sys/interface.h"

extern APP_OBJ example_app;

#endif