# 天气API
### 目前使用两套API接口
1. 和风：https://dev.qweather.com/docs/start/  官网地址：https://devapi.qweather.com/v7/weather/now?location=101010100&key=你的KEY
2. 知心：https://api.seniverse.com/v3/weather/now.json?key=your_api_key&location=beijing&language=zh-Hans&unit=c   知心官网地址：https://seniverse.com

### 关于天气图标
目前给定的也是两套天气图标，和风的天气图标较为好看。下载地址：https://github.com/qwd/WeatherIcon