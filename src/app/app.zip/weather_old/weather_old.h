#ifndef APP_WEATHER_OLD_H
#define APP_WEATHER_OLD_H

#define WEATHER_OLD_APP_NAME "Weather Old"
#include "sys/interface.h"

extern APP_OBJ weather_old_app;

#endif