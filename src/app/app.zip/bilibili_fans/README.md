# B站粉丝功能

> 作者：程序员小志

> 时间：2021-11-24 00:58
> 修改：2022-02-27 16:12 By ClimbSnail

> 功能描述：获取UP主的粉丝数、关注数，显示头像

## 查看自己的头像
https://api.bilibili.com/x/relation/stat?vmid=344470052

https://api.bilibili.com/x/space/upstat?mid=344470052

https://dmscode.github.io/simple-tool-pages/bilibili-fans/#344470052