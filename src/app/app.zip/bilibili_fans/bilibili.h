#ifndef APP_BILIBILI_H
#define APP_BILIBILI_H


#define BILI_APP_NAME "Bili"
#include "sys/interface.h"

extern APP_OBJ bilibili_app;

#endif