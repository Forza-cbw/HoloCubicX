#ifndef APP_PICTURE_H
#define APP_PICTURE_H

#include "sys/interface.h"

#define IMAGE_PATH "/image"

extern APP_OBJ picture_app;

#endif